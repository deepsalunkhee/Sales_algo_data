const tbody = document.querySelector(".el-table__body tbody");

if (tbody) {
  const rows = tbody.querySelectorAll("tr");

  rows.forEach((row) => {
    const rowCells = row.querySelectorAll("td");

    rowCells.forEach((cell) => {
      if (cell.classList.contains("el-table_1_column_1")) {
        const productTitle = cell.querySelector(".product_title");

        if (productTitle) {
          console.log("Product Title:", productTitle.textContent.trim());
        }
      } else if (cell.classList.contains("el-table_1_column_3")) {
        const sevday = cell.querySelector(".el-tooltip");

        if (sevday) {
          console.log("7daysale", sevday.textContent.trim());
        }
      } else if (cell.classList.contains("el-table_1_column_4")) {
        const cellSpans = cell.querySelectorAll(".el-tooltip span");

        if (cellSpans.length > 0) {
          cellSpans.forEach((span) => {
            console.log("TotalSale", span.textContent.trim());
          });
        }
      } else if (cell.classList.contains("el-table_1_column_5")) {
        const cellSpans = cell.querySelectorAll(".el-tooltip span");

        if (cellSpans.length > 0) {
          cellSpans.forEach((span) => {
            console.log("Review", span.textContent.trim());
          });
        }
      } else if (cell.classList.contains("el-table_1_column_6")) {
        const cellSpans = cell.querySelectorAll(".el-tooltip span");

        if (cellSpans.length > 0) {
          cellSpans.forEach((span) => {
            console.log("Favourite", span.textContent.trim());
          });
        }
      } else {
      }
    });
  });
}


///////////////////////////////////////////////////////////////////////////////////

const tbody = document.querySelector(".el-table__body tbody");

// Array to store extracted data
const extractedData = [];

if (tbody) {
  const rows = tbody.querySelectorAll("tr");

  rows.forEach((row) => {
    const rowCells = row.querySelectorAll("td");
    const rowData = {};

    rowCells.forEach((cell) => {
      if (cell.classList.contains("el-table_1_column_1")) {
        const productTitle = cell.querySelector(".product_title");

        if (productTitle) {
          rowData["Product Title"] = productTitle.textContent.trim();
        }
      } else if (cell.classList.contains("el-table_1_column_3")) {
        const sevday = cell.querySelector(".el-tooltip");

        if (sevday) {
          rowData["7 Day Sale"] = sevday.textContent.trim();
        }
      } else if (cell.classList.contains("el-table_1_column_4")) {
        const cellSpans = cell.querySelectorAll(".el-tooltip span");

        if (cellSpans.length > 0) {
          rowData["Total Sale"] = cellSpans[0].textContent.trim();
        }
      } else if (cell.classList.contains("el-table_1_column_5")) {
        const cellSpans = cell.querySelectorAll(".el-tooltip span");

        if (cellSpans.length > 0) {
          rowData["Review"] = cellSpans[0].textContent.trim();
        }
      } else if (cell.classList.contains("el-table_1_column_6")) {
        const cellSpans = cell.querySelectorAll(".el-tooltip span");

        if (cellSpans.length > 0) {
          rowData["Favorite"] = cellSpans[0].textContent.trim();
        }
      }
    });

    // Push rowData object to extractedData array
    extractedData.push(rowData);
  });

  // Generate CSV string
  const csvContent = "data:text/csv;charset=utf-8,";

  // Custom column headers for CSV
  const headers = [
    "Product Title",
    "7 Day Sale",
    "Total Sale",
    "Review",
    "Favorite",
  ];
  csvContent += headers.join(",") + "\r\n";

  // Add rows to CSV
  extractedData.forEach((row) => {
    const values = headers.map((header) => row[header] || "").join(",");
    csvContent += values + "\r\n";
  });

  // Display or use the CSV content as needed
  console.log(csvContent);
}



///////////////////////////////////////////////////////////////////////////////////

const tbody = document.querySelector(".el-table__body tbody");

// Array to store extracted data
const extractedData = [];

if (tbody) {
  const rows = tbody.querySelectorAll("tr");

  rows.forEach((row) => {
    const rowCells = row.querySelectorAll("td");
    const rowData = {};

    rowCells.forEach((cell) => {
      if (cell.classList.contains("el-table_1_column_1")) {
        const productTitle = cell.querySelector(".product_title");

        if (productTitle) {
          rowData["Product Title"] = productTitle.textContent.trim();
        }

        const productCost = cell.querySelector(".src-css-product-productInfoSub-3svU div:nth-child(1)");

        if (productCost) {
          rowData["Cost"] = productCost.textContent.trim();
        }
      } else if (cell.classList.contains("el-table_1_column_3")) {
        const sevday = cell.querySelector(".el-tooltip");

        if (sevday) {
          rowData["7 Day Sale"] = sevday.textContent.trim();
        }
      } else if (cell.classList.contains("el-table_1_column_4")) {
        const cellSpans = cell.querySelectorAll(".el-tooltip span");

        if (cellSpans.length > 0) {
          rowData["Total Sale"] = cellSpans[0].textContent.trim();
        }
      } else if (cell.classList.contains("el-table_1_column_5")) {
        const cellSpans = cell.querySelectorAll(".el-tooltip span");

        if (cellSpans.length > 0) {
          rowData["Review"] = cellSpans[0].textContent.trim();
        }
      } else if (cell.classList.contains("el-table_1_column_6")) {
        const cellSpans = cell.querySelectorAll(".el-tooltip span");

        if (cellSpans.length > 0) {
          rowData["Favorite"] = cellSpans[0].textContent.trim();
        }
      }
    });

    // Push rowData object to extractedData array
    extractedData.push(rowData);
  });

  // Generate CSV string
  const csvContent = "data:text/csv;charset=utf-8,";

  // Custom column headers for CSV
  const headers = [
    "Product Title",
    "Cost",
    "7 Day Sale",
    "Total Sale",
    "Review",
    "Favorite",
  ];
  csvContent += headers.join(",") + "\r\n";

  // Add rows to CSV
  extractedData.forEach((row) => {
    const values = headers.map((header) => row[header] || "").join(",");
    csvContent += values + "\r\n";
  });

  // Display or use the CSV content as needed
  console.log(csvContent);
}


///////////////////////////////////////////////////////////////////////////////////

const tbody = document.querySelector(".el-table__body tbody");

// Array to store extracted data
const extractedData = [];

if (tbody) {
  const rows = tbody.querySelectorAll("tr");

  rows.forEach((row) => {
    const rowCells = row.querySelectorAll("td");
    const rowData = {};

    rowCells.forEach((cell) => {
      if (cell.classList.contains("el-table_1_column_1")) {
        const productTitle = cell.querySelector(".product_title");

        if (productTitle) {
          rowData["Product Title"] = String(productTitle.textContent.trim());
        }

        const productCost = cell.querySelector(".src-css-product-productInfoSub-3svU div:nth-child(1)");

        if (productCost) {
          rowData["Cost"] = String(productCost.textContent.trim());
        }
      } else if (cell.classList.contains("el-table_1_column_3")) {
        const sevday = cell.querySelector(".el-tooltip");

        if (sevday) {
          rowData["7 Day Sale"] = String(sevday.textContent.trim());
        }
      } else if (cell.classList.contains("el-table_1_column_4")) {
        const cellSpans = cell.querySelectorAll(".el-tooltip span");

        if (cellSpans.length > 0) {
          rowData["Total Sale"] = String(cellSpans[0].textContent.trim());
        }
      } else if (cell.classList.contains("el-table_1_column_5")) {
        const cellSpans = cell.querySelectorAll(".el-tooltip span");

        if (cellSpans.length > 0) {
          rowData["Review"] = String(cellSpans[0].textContent.trim());
        }
      } else if (cell.classList.contains("el-table_1_column_6")) {
        const cellSpans = cell.querySelectorAll(".el-tooltip span");

        if (cellSpans.length > 0) {
          rowData["Favorite"] = String(cellSpans[0].textContent.trim());
        }
      }
    });

    // Push rowData object to extractedData array
    extractedData.push(rowData);
  });

  // Generate CSV string
 // ... (Previous code remains unchanged until this point)

// Generate CSV string
const csvContent = "data:text/csv;charset=utf-8,";

// Custom column headers for CSV
const headers = [
  "Product Title",
  "Cost",
  "7 Day Sale",
  "Total Sale",
  "Review",
  "Favorite",
];
csvContent += headers.map(header => `"${String(header)}"`).join(",") + "\r\n";

// Add rows to CSV
extractedData.forEach((row) => {
  const values = headers.map((header) => {
    const cellValue = String(row[header] || "");
    // Check if the cell value contains commas, if yes, enclose it within double quotes
    return cellValue.includes(",") ? `"${cellValue}"` : cellValue;
  }).join(",");
  csvContent += values + "\r\n";
});

// Display or use the CSV content as needed
console.log(csvContent);

}
///////////////////////////////////////////////////////////////////////////////////
//alura testing script
const priceElement = document.getElementById("lr-details_price");


  // Get the text content of the element
  const priceText = priceElement.textContent.trim();

  // Remove non-numeric characters using regular expression
  const numericPriceString = priceText.replace(/[^0-9.]/g, '');

  // Convert the numeric string to an integer
  const price = parseInt(numericPriceString, 10);


const favoritesElement21 = document.getElementById("lr-details_favorites");


  const favoritesText = favoritesElement21.textContent.trim();

  // Convert the text content to an integer
  const fav = parseInt(favoritesText, 10);

  

const viewsElement = document.getElementById("lr-details_views");


  const viewsText = viewsElement.textContent.trim();

  // Remove any non-numeric characters (like spaces) using regular expression
  const numericViewsString = viewsText.replace(/\D/g, '');

  // Convert the numeric string to an integer
  const viewsValue = parseInt(numericViewsString, 10);


const reviewRateElement = document.getElementById("lr-details_review-rate");


  const reviewRateText = reviewRateElement.textContent.trim();

  // Remove the percentage sign and convert to a numeric value
  const reviewRateValue = parseFloat(reviewRateText.replace('%', ''));

 

const salesElement1 = document.getElementById("lr-overview_sales");


  // Get the text content of the element
  const salesText = salesElement1.textContent.trim();

  // Convert the text content to an integer
  const thersale = parseInt(salesText, 10);

  // Display or use the converted integer value
  




const rev=thersale*(reviewRateValue/100)


const sale=0.871917*rev + 0.750783*fav + -0.142339 *price
console.log(sale)
/////////////////////////////////////////////////////////////////////////////
alura.io
// Get the elements by their IDs
const priceElement = document.getElementById("lr-details_price");
const favoritesElement21 = document.getElementById("lr-details_favorites");
const viewsElement = document.getElementById("lr-details_views");
const reviewRateElement = document.getElementById("lr-details_review-rate");
const salesElement1 = document.getElementById("lr-overview_sales");

// Function to clean and convert text content to numeric values
const extractNumericValue = (element) => {
  const text = element.textContent.trim();
  const numericString = text.replace(/[^0-9.%]/g, ''); // Remove non-numeric characters
  if (numericString.includes('%')) {
    return parseFloat(numericString.replace('%', ''));
  } else {
    return parseInt(numericString, 10);
  }
};

// Extracting values from elements
const price = parseFloat(priceElement.textContent.trim().replace(/[^0-9.]/g, ''));
const favorites = parseInt(favoritesElement21.textContent.trim(), 10);
const views = parseInt(viewsElement.textContent.trim().replace(/\D/g, ''), 10);

const sales = parseInt(salesElement1.textContent.trim(), 10);
const review = (extractNumericValue(reviewRateElement))/100*sales;
const revenue = sales * (reviewRate / 100);

// Creating a CSV string
const csvContent = `Price,Favorites,Views,Review,Sales\n${price},${favorites},${views},${review},${sales}`;

console.log(csvContent); // Output the CSV content to console (you can modify this to save it elsewhere)
/////////////////////////////////////////////////////////////////////////////

// alura.io
// Get the element by its ID for favorites
const favoritesElement2 = document.getElementById('lr-details_favorites');
if (favoritesElement2 !== null) {
    const favoritesValue = favoritesElement2.textContent.trim().replace(/\s/g, ''); // Remove spaces
    const favoritesInteger = parseInt(favoritesValue, 10); // Parse to integer
    console.log('Favorites:', favoritesInteger);
} else {
    console.log('Element lr-details_favorites not found');
}

// Get the element by its ID for sales
const salesElement = document.getElementById('lr-overview_sales');
if (salesElement !== null) {
    const salesValue = salesElement.textContent.trim().replace(/\s/g, ''); // Remove spaces
    const salesInteger = parseInt(salesValue, 10);
    console.log('Sales:', salesInteger);
} else {
    console.log('Element lr-overview_sales not found');
}

// Get the element by its ID for price
const priceElement = document.getElementById('lr-details_price');
if (priceElement !== null) {
    const priceValue = priceElement.textContent.trim().replace('$', ''); // Remove $ symbol
    const priceFloat = parseFloat(priceValue); // Parse to float
    console.log('Price:', priceFloat);
} else {
    console.log('Element lr-details_price not found');
}


//////////////////////////////////////////////////////

// alura.io
// Given data and calculations
const favoritesElement2 = document.getElementById('lr-details_favorites');
const favoritesValue = favoritesElement2.textContent.trim().replace(/\s/g, '');
const favoritesInteger = parseInt(favoritesValue, 10);

const salesElement = document.getElementById('lr-overview_sales');
const salesValue = salesElement.textContent.trim().replace(/\s/g, '');
const salesInteger = parseInt(salesValue, 10);

const priceElement = document.getElementById('lr-details_price');
const priceValue = priceElement.textContent.trim().replace('$', '');
const priceFloat = parseFloat(priceValue);

const reviewRateElement = document.getElementById('lr-details_review-rate');
const reviewRateValue = reviewRateElement.textContent.trim().replace('%', '');
const reviewRateFloat = parseFloat(reviewRateValue);

// Get the element by its ID for image title
const imageTitleElement1 = document.getElementById('lr-image_title');

    const imageTitle1 = imageTitleElement1.textContent.trim();
    console.log('Image Title:', imageTitle1);



const rev = salesInteger * (reviewRateFloat / 100);
const calsales = -0.445537 * priceFloat + 0.831706 * rev + 0.408027 * favoritesInteger;

// Prepare CSV data
const csvData = [
    ['Favorites', 'Sales', 'Price', 'Review Rate', 'Image Title', 'Calculated Sales'],
    [favoritesInteger, salesInteger, priceFloat, reviewRateFloat, imageTitle1, calsales]
];

// Function to convert data to CSV format
function convertToCSV(array) {
    return array.map(row => row.join(',')).join('\n');
}

// Convert data to CSV format
const csvContent = convertToCSV(csvData);

// Log CSV content to console
console.log(csvContent);
//////////////////////////////////////////////////////
// hunt
const tbody = document.querySelector(".el-table__body tbody");


const extractedData = [];

if (tbody) {
  const rows = tbody.querySelectorAll("tr");

  rows.forEach((row) => {
    const rowCells = row.querySelectorAll("td");
    const rowData = {};

    rowCells.forEach((cell) => {
      if (cell.classList.contains("el-table_1_column_1")) {
        const productTitle = cell.querySelector(".product_title");

        if (productTitle) {
          rowData["Product Title"] = String(productTitle.textContent.trim());
        }

        const productCost = cell.querySelector(".src-css-product-productInfoSub-3svU div:nth-child(1)");

        if (productCost) {
          rowData["Cost"] = String(productCost.textContent.trim());
        }
      } else if (cell.classList.contains("el-table_1_column_3")) {
        const sevday = cell.querySelector(".el-tooltip");

        if (sevday) {
          rowData["7 Day Sale"] = String(sevday.textContent.trim());
        }
      } else if (cell.classList.contains("el-table_1_column_4")) {
        const cellSpans = cell.querySelectorAll(".el-tooltip span");

        if (cellSpans.length > 0) {
          rowData["Total Sale"] = String(cellSpans[0].textContent.trim());
        }
      } else if (cell.classList.contains("el-table_1_column_5")) {
        const cellSpans = cell.querySelectorAll(".el-tooltip span");

        if (cellSpans.length > 0) {
          rowData["Review"] = String(cellSpans[0].textContent.trim());
        }
      } else if (cell.classList.contains("el-table_1_column_6")) {
        const cellSpans = cell.querySelectorAll(".el-tooltip span");

        if (cellSpans.length > 0) {
          rowData["Favorite"] = String(cellSpans[0].textContent.trim());
        }
      }
    });

   
    extractedData.push(rowData);
  });

  

// Generate CSV string
let csvContent = "data:text/csv;charset=utf-8,";

// Custom column headers for CSV
const headers = [
  "Product Title",
  "Cost",
  "7 Day Sale",
  "Total Sale",
  "Review",
  "Favorite",
];
csvContent += headers.map(header => `"${String(header)}"`).join(",") + "\r\n";

// Add rows to CSV
extractedData.forEach((row) => {
  const values = headers.map((header) => {
    const cellValue = String(row[header] || "");
    // Check if the cell value contains commas, if yes, enclose it within double quotes
    return cellValue.includes(",") ? `"${cellValue}"` : cellValue;
  }).join(",");
  csvContent += values + "\r\n";
});

// Display or use the CSV content as needed
console.log(csvContent);

}
//////////////////////////////////////////////////////
//alrura
// Given data and calculations
const favoritesElement2 = document.getElementById('lr-details_favorites');
const favoritesValue = favoritesElement2.textContent.trim().replace(/\s/g, '');
const favoritesInteger = parseInt(favoritesValue, 10);

const salesElement = document.getElementById('lr-overview_sales');
const salesValue = salesElement.textContent.trim().replace(/\s/g, '');
const salesInteger = parseInt(salesValue, 10);

const priceElement = document.getElementById('lr-details_price');
const priceValue = priceElement.textContent.trim().replace('$', '');
const priceFloat = parseFloat(priceValue);

const reviewRateElement = document.getElementById('lr-details_review-rate');
const reviewRateValue = reviewRateElement.textContent.trim().replace('%', '');
const reviewRateFloat = parseFloat(reviewRateValue);

// Get the element by its ID for image title
const imageTitleElement1 = document.getElementById('lr-image_title');
const imageTitle1 = imageTitleElement1.textContent.trim().replace(/,/g, ''); // Remove commas from image title
console.log('Image Title:', imageTitle1);

const rev = salesInteger * (reviewRateFloat / 100);
const calsales = -0.445537 * priceFloat + 0.831706 * rev + 0.408027 * favoritesInteger;

// Prepare CSV data
const csvData = [
    ['Favorites', 'Sales', 'Price', 'Review Rate', 'Image Title', 'Calculated Sales'],
    [favoritesInteger, salesInteger, priceFloat, reviewRateFloat, imageTitle1, calsales]
];

// Function to convert data to CSV format
function convertToCSV(array) {
    return array.map(row => row.map(cell => cell.toString().replace(/,/g, '')).join(',')).join('\n');
    // The 'map' function is used to remove commas from each cell value before joining the rows.
}

// Convert data to CSV format
const csvContent = convertToCSV(csvData);

// Log CSV content to console
console.log(csvContent);
//////////////////////////////////////////////////////
// Given data and calculations
const favoritesElement2 = document.getElementById('lr-details_favorites');
const favoritesValue = favoritesElement2.textContent.trim().replace(/\s/g, '');
const favoritesInteger = parseInt(favoritesValue, 10);

const salesElement = document.getElementById('lr-overview_sales');
const salesValue = salesElement.textContent.trim().replace(/\s/g, '');
const salesInteger = parseInt(salesValue, 10);

const priceElement = document.getElementById('lr-details_price');
const priceValue = priceElement.textContent.trim().replace('$', '');
const priceFloat = parseFloat(priceValue);

const reviewRateElement = document.getElementById('lr-details_review-rate');
const reviewRateValue = reviewRateElement.textContent.trim().replace('%', '');
const reviewRateFloat = parseFloat(reviewRateValue);

// Get the element by its ID for image title
const imageTitleElement1 = document.getElementById('lr-image_title');
const imageTitle1 = imageTitleElement1.textContent.trim().replace(/,/g, ''); // Remove commas from image title
console.log('Image Title:', imageTitle1);

// Get the element by its ID
const viewsElement = document.getElementById('lr-details_views');


    const viewsValue = viewsElement.textContent.trim().replace(/\s/g, ''); // Remove spaces
   



const rev = salesInteger * (reviewRateFloat / 100);
const calsales = 28.57 + -1.52 * rev + 0.76 * favoritesInteger + -0.17 *priceFloat

// Prepare CSV data
const csvData = [
    ['Favorites', 'Sales', 'Price', 'Review Rate', 'Image Title', 'Calculated Sales','Views'],
    [favoritesInteger, salesInteger, priceFloat, reviewRateFloat, imageTitle1, calsales,viewsValue]
];

// Function to convert data to CSV format
function convertToCSV(array) {
    return array.map(row => row.map(cell => cell.toString().replace(/,/g, '')).join(',')).join('\n');
    // The 'map' function is used to remove commas from each cell value before joining the rows.
}

// Convert data to CSV format
const csvContent = convertToCSV(csvData);

// Log CSV content to console
console.log(csvContent);
//////////////////////////////////////////////////////

